import smtplib
import os
import traceback
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

from shared.config.settings import load_config, get_settings, get_logger, get_email_settings
from shared.services.logging_service import ProcessType

class EmailService:
    def __init__(self):
        self.config = load_config()
        self.settings = get_email_settings()
        self.project_root = Path(__file__).parent.parent.parent
        self.logger = get_logger()

    def _get_email_settings(self) -> Dict[str, Any]:
        """Retorna as configurações de email do config.json"""
        email_settings = self.config.get('email', {})
        if not email_settings.get('enabled', False):
            self.logger.log_warning("email_config", "Serviço de email está desabilitado", ProcessType.SYSTEM)
        return email_settings

    def _get_email_credentials(self):
        """Obtém as credenciais de email do arquivo .env"""
        sender = os.getenv('EMAIL_SENDER')
        password = os.getenv('EMAIL_PASSWORD')
        
        if not sender or not password:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
            self.logger.log_error("email_credentials", f"Credenciais de email não encontradas no arquivo .env{tb_info}", ProcessType.SYSTEM)
            raise ValueError("Credenciais de email não encontradas no arquivo .env")
        return sender, password
    
    def _get_email_config(self):
        """Obtém as configurações de email do config.json"""
        email_config = self.config.get('email', {})
        if not email_config.get('enabled', False):
            self.logger.log_warning("email_config", "Serviço de email está desabilitado", ProcessType.SYSTEM)
            raise ValueError("Serviço de email está desabilitado")
        return email_config
    
    def _load_template(self, template_name: str, variables: Dict[str, Any]) -> str:
        """Carrega e processa um template HTML"""
        template_path = self.project_root / self.config['paths']['email_templates'] / f"{template_name}.html"
        
        if not template_path.exists():
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
            error_msg = f"Template {template_name} não encontrado em {template_path}{tb_info}"
            self.logger.log_error("email_template", error_msg, ProcessType.SYSTEM)
            raise FileNotFoundError(error_msg)
            
        try:
            with open(template_path, 'r', encoding='utf-8') as file:
                template_content = file.read()

            # Substitui as variáveis no template - CORREÇÃO: usar {{key}} ao invés de {{{{key}}}}
            variables_replaced = 0
            for key, value in variables.items():
                old_content = template_content
                template_content = template_content.replace(f"{{{{{key}}}}}", str(value))
                if old_content != template_content:
                    variables_replaced += 1
            return template_content
            
        except Exception as e:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
            error_msg = f"Erro ao processar template {template_name}: {str(e)}{tb_info}"
            self.logger.log_error("email_template", error_msg, ProcessType.SYSTEM)
            raise
    
    def _send_email(self, subject: str, html_body: str, recipient: str = None):
        """Envia um email HTML"""
        try:
            sender, password = self._get_email_credentials()
            email_config = self._get_email_config()
            
            if not recipient:
                recipient = email_config['recipient']
            # Criar mensagem
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = sender
            msg['To'] = recipient
            
            # Adicionar corpo HTML
            html_part = MIMEText(html_body, 'html', 'utf-8')
            msg.attach(html_part)
            
            # Enviar email
            smtp_server = email_config.get('smtp_server', 'smtp.gmail.com')
            smtp_port = email_config.get('smtp_port', 465)

            with smtplib.SMTP_SSL(smtp_server, smtp_port) as server:
                server.login(sender, password)
                server.sendmail(sender, recipient, msg.as_string())
                
            self.logger.log_success("email_send", f"Email enviado com sucesso para {recipient} - Assunto: {subject}", ProcessType.SYSTEM)
            return True
            
        except Exception as e:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
            error_msg = f"Erro ao enviar email: {str(e)}{tb_info}"
            self.logger.log_error("email_send", error_msg, ProcessType.SYSTEM)
            return False
    
    def send_process_start_email(self, start_time: datetime = None):
        """Envia email de início do processo"""

        if get_email_settings().get('enabled', False) is False:
            self.logger.log_warning("send_process_start_email", "Serviço de email está desabilitado, não enviando email de início", ProcessType.SYSTEM)
            return False

        if start_time is None:
            start_time = datetime.now()
            
        project_info = self.config['project_info']
        
        variables = {
            'project_name': project_info['name'],
            'project_version': project_info['version'],
            'start_time': start_time.strftime('%d/%m/%Y às %H:%M:%S'),
            'environment': self.config['settings'].get('environment', 'Não especificado')
        }
        
        subject = f"RPA {project_info['name']} - Status: Processo Iniciado"

        try:
            html_body = self._load_template('inicio', variables)
            result = self._send_email(subject, html_body)
            if not result:
                tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
                self.logger.log_error("email_process_start", f"Falha ao enviar email de início do processo{tb_info}", ProcessType.SYSTEM)
            return result
        except Exception as e:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
            error_msg = f"Erro ao processar email de início: {str(e)}{tb_info}"
            self.logger.log_error("email_process_start", error_msg, ProcessType.SYSTEM)
            return False
    
    def send_process_end_email(self, start_time: datetime, end_time: datetime = None):
        """Envia email de fim do processo"""

        if get_email_settings().get('enabled', False) is False:
            self.logger.log_warning("send_process_end_email", "Serviço de email está desabilitado, não enviando email de finalização", ProcessType.SYSTEM)
            return False
        
        if end_time is None:
            end_time = datetime.now()
            
        duration = end_time - start_time
        duration_str = str(duration).split('.')[0]  # Remove microsegundos
        
        project_info = self.config['project_info']
        
        variables = {
            'project_name': project_info['name'],
            'project_version': project_info['version'],
            'start_time': start_time.strftime('%d/%m/%Y às %H:%M:%S'),
            'end_time': end_time.strftime('%d/%m/%Y às %H:%M:%S'),
            'duration': duration_str
        }
        
        subject = f"RPA {project_info['name']} - Status: Processo Finalizado"

        try:
            html_body = self._load_template('fim', variables)
            result = self._send_email(subject, html_body)
            
            if not result:
                tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
                self.logger.log_error("email_process_end", f"Falha ao enviar email de fim do processo{tb_info}", ProcessType.SYSTEM)
                
            return result
            
        except Exception as e:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
            error_msg = f"Erro ao processar email de fim: {str(e)}{tb_info}"
            self.logger.log_error("email_process_end", error_msg, ProcessType.SYSTEM)
            return False
    
    def send_process_error_email(self, start_time: datetime, error_message: str, error_location: str = "", error_time: datetime = None):
        """Envia email de erro crítico do processo"""

        if get_email_settings().get('enabled', False) is False:
            self.logger.log_warning("send_process_error_email", "Serviço de email está desabilitado, não enviando email de erro.", ProcessType.SYSTEM)
            return False

        if error_time is None:
            error_time = datetime.now()
            
        project_info = self.config['project_info']
        
        variables = {
            'project_name': project_info['name'],
            'project_version': project_info['version'],
            'start_time': start_time.strftime('%d/%m/%Y às %H:%M:%S'),
            'error_time': error_time.strftime('%d/%m/%Y às %H:%M:%S'),
            'error_message': error_message,
            'error_location': error_location or 'Não especificado'
        }
        
        subject = f"RPA {project_info['name']} - Status: Processo Interrompido"
        
        try:
            html_body = self._load_template('erro', variables)
            result = self._send_email(subject, html_body)
            
            if not result:
                tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
                self.logger.log_error("email_process_error", f"Falha ao enviar email de erro crítico{tb_info}", ProcessType.SYSTEM)
                
            return result
            
        except Exception as e:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
            error_msg = f"Erro ao processar email de erro: {str(e)}{tb_info}"
            self.logger.log_error("email_process_error", error_msg, ProcessType.SYSTEM)
            return False

# Instância global do serviço de email
_email_service = None

def get_email_service() -> EmailService:
    """Retorna a instância global do serviço de email"""
    global _email_service
    if _email_service is None:
        _email_service = EmailService()
    return _email_service

# Funções de conveniência para compatibilidade
def send_process_start_email(start_time: datetime = None):
    return get_email_service().send_process_start_email(start_time)

def send_process_end_email(start_time: datetime, end_time: datetime = None):
    return get_email_service().send_process_end_email(start_time, end_time)

def send_process_error_email(start_time: datetime, error_message: str, error_location: str = "", error_time: datetime = None):
    return get_email_service().send_process_error_email(start_time, error_message, error_location, error_time)

# Função de teste para debug
def test_email_template():
    """Função para testar o envio de email e verificar se as variáveis estão sendo substituídas"""
    logger = get_logger()
    
    try:
        email_service = get_email_service()
        start_time = datetime.now()
        
        # Teste do email de fim de processo
        result = email_service.send_process_end_email(start_time)
        
        if not result:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
            logger.log_error("email_test", f"Falha no teste de email{tb_info}", ProcessType.SYSTEM)
            
    except Exception as e:
        tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
        logger.log_error("email_test", f"Erro no teste de email: {str(e)}{tb_info}", ProcessType.SYSTEM)
