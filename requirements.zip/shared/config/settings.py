import json
import os
import re
from pathlib import Path
from typing import Dict, Any
from dotenv import load_dotenv

# Carrega variáveis de ambiente
load_dotenv()

CONFIG_FILE = Path(__file__).parent / "config.json"

def load_config() -> Dict[str, Any]:
    """Carrega configurações do arquivo JSON e substitui variáveis de ambiente."""
    try:
        with open(CONFIG_FILE, 'r', encoding='utf-8') as file:
            config_content = file.read()
            
        # Substitui variáveis de ambiente no formato ${VAR_NAME}
        def replace_env_vars(match):
            var_name = match.group(1)
            return os.getenv(var_name, match.group(0))
        
        config_content = re.sub(r'\$\{([^}]+)\}', replace_env_vars, config_content)
        return json.loads(config_content)
        
    except FileNotFoundError:
        raise FileNotFoundError(f"Arquivo de configuração não encontrado: {CONFIG_FILE}")
    except json.JSONDecodeError:
        raise ValueError(f"Erro ao decodificar o arquivo JSON: {CONFIG_FILE}")

# Constantes para nomes de variáveis de ambiente
LOGS_ENV = 'RPA_LOGS_PATH'
REPORTS_ENV = 'RPA_REPORTS_PATH'
SCREENSHOTS_ENV = 'RPA_SCREENSHOTS_PATH'

def set_environment_variables() -> None:
    """Define variáveis de ambiente baseadas na configuração."""
    config = load_config()
    paths = config.get('paths', {})
    
    os.environ[LOGS_ENV] = paths.get('logs', '')
    os.environ[REPORTS_ENV] = paths.get('reports', '')
    os.environ[SCREENSHOTS_ENV] = paths.get('screenshots', '')

def get_logs_path() -> str:
    """Retorna o caminho dos logs das variáveis de ambiente."""
    return os.environ.get(LOGS_ENV, '')

def get_reports_path() -> str:
    """Retorna o caminho dos relatórios das variáveis de ambiente."""
    return os.environ.get(REPORTS_ENV, '')

def get_screenshots_path() -> str:
    """Retorna o caminho das capturas de tela das variáveis de ambiente."""
    return os.environ.get(SCREENSHOTS_ENV, '')

def get_project_info() -> Dict[str, Any]:
    """Retorna informações do projeto."""
    config = load_config()
    return config.get('project_info', {})

def get_settings() -> Dict[str, Any]:
    """Retorna configurações gerais do projeto."""
    config = load_config()
    return config.get('settings', {})

def get_email_settings() -> Dict[str, Any]:
    """Retorna configurações do serviço de email."""
    config = load_config()
    return config.get('email', {})


class Config:
    """Classe para gerenciar configurações globais do projeto."""
    def __init__(self):
        self.logs_path: str | None = None
        self.reports_path: str | None = None
        self.screenshots_path: str | None = None
        self.logger = None
        self.project_info: Dict[str, Any] = {}
        self.settings: Dict[str, Any] = {}
        self.database_config: Dict[str, Any] = {}

config_instance = Config()

def initialize_global_paths() -> None:
    """Inicializa caminhos globais e configurações do projeto."""
    set_environment_variables()
    config_instance.logs_path = get_logs_path()
    config_instance.reports_path = get_reports_path()
    config_instance.screenshots_path = get_screenshots_path()
    config_instance.project_info = get_project_info()
    config_instance.settings = get_settings()
    config = load_config()
    config_instance.database_config = config.get('database', {})

def get_global_logs_path() -> str | None:
    """Retorna o caminho global dos logs."""
    return config_instance.logs_path

def get_global_reports_path() -> str | None:
    """Retorna o caminho global dos relatórios."""
    return config_instance.reports_path

def get_global_screenshots_path() -> str | None:
    """Retorna o caminho global das capturas de tela."""
    return config_instance.screenshots_path

def get_logger():
    """Retorna a instância do logger global."""
    return config_instance.logger

def initialize_logging() -> None:
    """Inicializa o sistema de logging."""
    if config_instance.logger is None:
        from ..services.logging_service import EnhancedLogger
        
        # Determina o diretório de logs
        log_dir = None
        if config_instance.logs_path:
            base_path = Path(__file__).parent.parent.parent
            log_dir = str(base_path / config_instance.logs_path)
        
        # Cria o logger com o diretório correto
        project_info = get_project_info()
        project_name = project_info.get('name', 'SeuProjetoRPA')
        config_instance.logger = EnhancedLogger(project_name, log_dir)
        
        # Configura debug mode
        debug_mode = config_instance.settings.get('debug_mode', True)
        config_instance.logger.debug_mode = debug_mode

def create_directories_if_needed() -> None:
    """Cria diretórios necessários se não existirem."""
    base_path = Path(__file__).parent.parent.parent
    
    directories = [
        base_path / (config_instance.logs_path or ''),
        base_path / (config_instance.reports_path or ''),
        base_path / (config_instance.screenshots_path or '')
    ]
    
    for directory in directories:
        if not directory.exists():
            directory.mkdir(parents=True, exist_ok=True)
            print(f"Diretório criado: {directory}")

def initialize_application() -> tuple[bool, str, dict]:
    """Inicializa completamente a aplicação com logging e configurações.
    
    Returns:
        tuple: (sucesso, mensagem_erro, informações_do_projeto)
    """
    try:
        # 1. Inicializa caminhos globais
        initialize_global_paths()
        create_directories_if_needed()
        
        # 2. Inicializa logging
        initialize_logging()
        logger = get_logger()
        if not logger:
            return False, "Não foi possível inicializar o sistema de logging!", {}
        
        # 3. Prepara informações do projeto
        project_info = get_project_info()
        
        return True, "", project_info
        
    except Exception as e:
        return False, f"Erro na inicialização da aplicação: {str(e)}", {}