import requests
from bs4 import BeautifulSoup
import csv
import os
import sys
from pathlib import Path
import json

# Adiciona o diretório raiz do projeto ao path
project_root = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(project_root))
sys.path.append(str(project_root / "shared"))

from shared.config.settings import get_logger
from shared.services.logging_service import ProcessType

class GetMatchesTask:
    def __init__(self):
        self.logger = get_logger()
        self.config = self._load_config()
        
    def _load_config(self):
        """Carrega a configuração do arquivo config.json"""
        try:
            config_path = project_root / "shared" / "config" / "config.json"
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            self.logger.log_error("config_load_error", f"Erro ao carregar configuração: {str(e)}", ProcessType.ROBOTIC)
            raise
    
    def execute(self):
        """Executa a extração de dados de matches"""
        try:
            self.logger.log_info("matches_extraction_start", "Iniciando extração de matches do FABTCG", ProcessType.ROBOTIC)
            
            # URL do site com os resultados
            url = self.config['fabtcg']['results_url']
            
            # Faz a requisição para a página
            try:
                response = requests.get(url)
                response.raise_for_status()
                self.logger.log_info("request_success", f"Requisição bem-sucedida para {url}", ProcessType.ROBOTIC)
            except requests.exceptions.RequestException as e:
                self.logger.log_error("request_error", f"Erro ao acessar a URL {url}: {str(e)}", ProcessType.ROBOTIC)
                return False

            # Analisa o conteúdo HTML da página
            soup = BeautifulSoup(response.content, 'html.parser')

            # Encontra todas as linhas de resultados dos jogos
            match_rows = soup.find_all('div', class_='tournament-coverage__row--results')
            self.logger.log_info("matches_found", f"Encontrados {len(match_rows)} matches", ProcessType.ROBOTIC)

            # Cria o diretório de saída se não existir
            output_dir = project_root / "data" / "temp"
            output_dir.mkdir(parents=True, exist_ok=True)
            
            # Abre um arquivo CSV para salvar os dados
            output_file = output_dir / "match.csv"
            with open(output_file, 'w', newline='', encoding='utf-8') as f:
                # Cria o escritor de CSV e define os nomes das colunas
                writer = csv.writer(f)
                writer.writerow(['player1', 'linkchecklistp1', 'player2', 'linkchecklistp2', 'winner'])

                # Itera sobre cada linha de resultado
                processed_matches = 0
                for match in match_rows:
                    try:
                        # --- Jogador 1 ---
                        player1_element = match.select_one('.tournament-coverage__p1')
                        player1_name = player1_element.select_one('.tournament-coverage__player-name-and-flag span').text.strip()
                        
                        # O link da decklist pode não existir, então usamos um try-except
                        try:
                            # O link está em uma tag <a> dentro da div do herói
                            link_p1_tag = player1_element.select_one('.tournament-coverage__player-hero-and-deck a')
                            link_p1 = link_p1_tag['href'] if link_p1_tag else 'N/A'
                        except (AttributeError, TypeError):
                            link_p1 = 'N/A'

                        # --- Jogador 2 ---
                        player2_element = match.select_one('.tournament-coverage__p2')
                        player2_name = player2_element.select_one('.tournament-coverage__player-name-and-flag span').text.strip()
                        
                        # Tenta obter o link da decklist do jogador 2
                        try:
                            link_p2_tag = player2_element.select_one('.tournament-coverage__player-hero-and-deck a')
                            link_p2 = link_p2_tag['href'] if link_p2_tag else 'N/A'
                        except (AttributeError, TypeError):
                            link_p2 = 'N/A'

                        # --- Vencedor ---
                        if 'tournament-coverage__row--winner-1' in match.get('class', []):
                            winner = player1_name
                        elif 'tournament-coverage__row--winner-2' in match.get('class', []):
                            winner = player2_name
                        elif 'tournament-coverage__row--draw' in match.get('class', []):
                            winner = "Draw" # Empate
                        else:
                            winner = "Não especificado"
                        
                        # Escreve a linha de dados no arquivo CSV
                        writer.writerow([player1_name, link_p1, player2_name, link_p2, winner])
                        processed_matches += 1

                    except AttributeError as e:
                        # Pula linhas que não tenham a estrutura esperada
                        self.logger.log_warning("match_parse_warning", f"Pulando uma linha de partida devido a um formato inesperado: {str(e)}", ProcessType.ROBOTIC)
                        continue

            self.logger.log_success("matches_extraction_complete", f"Dados extraídos e salvos com sucesso. {processed_matches} matches processados no arquivo '{output_file}'", ProcessType.ROBOTIC)
            return True
            
        except Exception as e:
            self.logger.log_error("matches_extraction_error", f"Erro na extração de matches: {str(e)}", ProcessType.ROBOTIC)
            return False