import sys
import os
from pathlib import Path
from datetime import datetime

# Adiciona o diretório raiz do projeto ao path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))
sys.path.append(str(project_root / "shared"))

from shared.config.settings import get_logger
from shared.services.logging_service import ProcessType
from workflows.getdatafnb.tasks.getmatches import GetMatchesTask
from workflows.getdatafnb.tasks.gettools import GetToolsTask
from workflows.getdatafnb.tasks.getpitch import GetPitchTask

class GetDataFnbOrchestrator:
    def __init__(self):
        self.logger = get_logger()
        
    def execute(self):
        """
        Executa o processo completo de extração de dados do FABTCG
        """
        try:
            self.logger.log_info("orchestrator_start", "Iniciando processo de extração de dados FABTCG", ProcessType.ROBOTIC)
            
            # 1. Executar GetMatches
            self.logger.log_info("matches_start", "Iniciando extração de matches", ProcessType.ROBOTIC)
            matches_task = GetMatchesTask()
            matches_result = matches_task.execute()
            
            if not matches_result:
                raise Exception("Falha na execução da task GetMatches")
            
            self.logger.log_success("matches_complete", "Extração de matches concluída com sucesso", ProcessType.ROBOTIC)
            
            # 2. Executar GetTools
            self.logger.log_info("tools_start", "Iniciando extração de tools/deck", ProcessType.ROBOTIC)
            tools_task = GetToolsTask()
            tools_result = tools_task.execute()
            
            if not tools_result:
                raise Exception("Falha na execução da task GetTools")
            
            self.logger.log_success("tools_complete", "Extração de tools/deck concluída com sucesso", ProcessType.ROBOTIC)
            
            # 3. Executar GetPitch
            self.logger.log_info("pitch_start", "Iniciando extração de pitch", ProcessType.ROBOTIC)
            pitch_task = GetPitchTask()
            pitch_result = pitch_task.execute()
            
            if not pitch_result:
                raise Exception("Falha na execução da task GetPitch")
            
            self.logger.log_success("pitch_complete", "Extração de pitch concluída com sucesso", ProcessType.ROBOTIC)
            
            self.logger.log_success("orchestrator_complete", "Processo completo de extração de dados FABTCG concluído com sucesso", ProcessType.ROBOTIC)
            return True
            
        except Exception as e:
            self.logger.log_error("orchestrator_error", f"Erro no orquestrador: {str(e)}", ProcessType.ROBOTIC)
            return False