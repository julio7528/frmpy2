import sys,os
import traceback
from pathlib import Path
from datetime import datetime

os.system('cls')
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))
sys.path.append(str(Path(__file__).parent / "shared"))

from shared.config import settings
from shared.config.settings import initialize_logging, get_logger, get_project_info
from shared.services.logging_service import ProcessType, LogStatus
from shared.services.database_service import get_db_manager
from shared.services.email_service import send_process_start_email, send_process_end_email, send_process_error_email
from shared.services.execution_service import get_execution_service

settings.initialize_global_paths()
settings.create_directories_if_needed()
success, error_msg, project_info = settings.initialize_application()
logger = get_logger()
project_name = project_info.get('name')
project_version = project_info.get('version')
db_manager = get_db_manager()
db_manager.connect()
execution_service = get_execution_service()
execution_service.create_execution_tables()

def main():
    start_time = datetime.now()
    execution_id = None
    
    try:
        # Handles the initial setup, including sending notifications and verifying that the required application is running.
        if not (execution_id := execution_service.start_execution()): raise Exception("Fail while trying to start execution")
        send_process_start_email(start_time)
        started = execution_service.start_transaction("Main Process")
        
        # Get transaction data
        # Capture Page Info     
        if started:
            try:
                # Importa e executa o orquestrador FABTCG
                from workflows.getdatafnb.orchgetdatafnb import GetDataFnbOrchestrator
                
                orchestrator = GetDataFnbOrchestrator()
                result = orchestrator.execute()
                
                if result:
                    logger.log_success("fabtcg_orchestrator", "Processo FABTCG concluído com sucesso", ProcessType.ROBOTIC)
                    execution_service.end_transaction("COMPLETED")
                else:
                    logger.log_error("fabtcg_orchestrator_error", "Falha na execução do processo FABTCG", ProcessType.ROBOTIC)
                    execution_service.end_transaction("ERROR")
                    
            except Exception as e:
                tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
                logger.log_error("transaction_error", f"Transaction error: {str(e)}{tb_info}", ProcessType.ROBOTIC)
                execution_service.end_transaction("ERROR")
        if not started:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
            logger.log_error("transaction_error", f"Transaction error: Falha ao iniciar transação{tb_info}", ProcessType.ROBOTIC)
            execution_service.end_transaction("ERROR")

      
        # Handles the end of the process, including sending notifications and closing the database connection.
        execution_service.end_execution("COMPLETED")
        send_process_end_email(start_time)
        logger.log_info("main_end", f":::Process ending:::", ProcessType.SYSTEM)
        db_manager.close()
        return 0
        
    except Exception as e:
        tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
        logger.log_error("transaction_error", f"Transaction error:: {str(e)}{tb_info}", ProcessType.ROBOTIC)
        if execution_id: execution_service.end_execution("ERROR")
        send_process_error_email(start_time, error_msg, "main()")
        return 1

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
