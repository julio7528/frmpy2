from shared.services.execution_service import get_execution_service
from shared.services.logging_service import get_logger, ProcessType

def process_data():
    execution_service = get_execution_service()
    logger = get_logger()
    
    # Iniciar transação para processamento de dados
    transaction_id = execution_service.start_transaction("Processamento de Dados")
    
    try:
        # Seus logs agora terão o identificador tr{id}
        logger.log_info("process_data", "Iniciando processamento de dados", ProcessType.BUSINESS)
        
        # Simular processamento
        # ... código do processamento ...
        
        logger.log_success("process_data", "Dados processados com sucesso", ProcessType.BUSINESS)
        
        # Finalizar transação com sucesso
        execution_service.end_transaction("COMPLETED")
        
    except Exception as e:
        logger.log_error("process_data", f"Erro no processamento: {str(e)}", ProcessType.BUSINESS)
        execution_service.end_transaction("ERROR")
        raise