import logging
import psycopg2
from typing import Optional, Tuple, Any
from ..config.settings import get_project_info, get_settings, get_logger
from .logging_service import EnhancedLogger, ProcessType, LogStatus

class DBManager:
    """
    Singleton para gerenciar a conexão com o banco de dados.
    Responsável por estabelecer e manter a conexão com o Supabase.
    """
    _instance: Optional['DBManager'] = None
    _connection: Optional[Any] = None
    _logger: Optional[EnhancedLogger] = None
    
    def __new__(cls) -> 'DBManager':
        if cls._instance is None:
            cls._instance = super(DBManager, cls).__new__(cls)
            cls._instance._initialize()
        return cls._instance
    
    def _initialize(self) -> None:
        """Inicializa o gerenciador de banco de dados."""
        self._connection = None
        
    def initialize_logging(self) -> EnhancedLogger:
        """Inicializa o logger antes de conectar ao banco de dados."""
        if not DBManager._logger:
            # Tenta obter o logger global primeiro
            DBManager._logger = get_logger()
            
            # Se não houver logger global, cria um novo
            if not DBManager._logger:
                project_info = get_project_info()
                proj_name = project_info.get('name')
                DBManager._logger = EnhancedLogger(proj_name)
                
                settings = get_settings()
                DBManager._logger.debug_mode = settings.get('debug_mode', True)
                
        return DBManager._logger
    
    def connect(self) -> bool:
        """Conecta ao banco de dados Supabase e retorna o status da conexão."""
        logger = self.initialize_logging()
        
        # Se já estiver conectado, verifica se a conexão ainda está ativa
        if self._connection:
            try:
                cursor = self._connection.cursor()
                cursor.execute('SELECT 1')
                cursor.close()
                logger.log_info("connect", "Usando conexão existente com o banco de dados", ProcessType.SYSTEM)
                return True
            except Exception:
                # Conexão inativa, fecha para reconectar
                self._connection = None
                logger.log_warning("connect", "Conexão perdida, tentando reconectar", ProcessType.SYSTEM)
        
        # Verifica se o banco de dados está habilitado nas configurações
        from ..config.settings import load_config
        config = load_config()
        db_config = config.get('database', {})
        if not db_config.get('enabled', False):
            logger.log_info("db_connect", ":::Processo Iniciado:::", ProcessType.SYSTEM)
            logger.log_warning("db_connect", "Conexão com banco de dados desabilitada nas configurações", ProcessType.SYSTEM)
            return False
        
        # Obtém credenciais das variáveis de ambiente
        import os
        host = os.getenv('SUPABASE_HOST')
        port = os.getenv('SUPABASE_PORT', '5432')
        database = os.getenv('SUPABASE_DATABASE')
        user = os.getenv('SUPABASE_USER')
        password = os.getenv('SUPABASE_PASSWORD')
        schema = os.getenv('SUPABASE_SCHEMA', 'public')
        
        # Verifica se todas as credenciais necessárias estão disponíveis
        if not all([host, database, user, password]):
            logger.log_error("db_connect", "Credenciais do Supabase não encontradas nas variáveis de ambiente", ProcessType.SYSTEM)
            return False
        
        # Tenta estabelecer a conexão com o Supabase
        try:
            settings = get_settings()
            
            # Estabelece a conexão
            self._connection = psycopg2.connect(
                host=host,
                port=int(port),
                database=database,
                user=user,
                password=password
            )
            
            # Testando a conexão
            cursor = self._connection.cursor()
            cursor.execute('SELECT version()')
            version = cursor.fetchone()[0]
            cursor.close()
            logger.log_info("connect", f":::Processo Iniciado:::", ProcessType.SYSTEM)
            logger.log_success("connect", f"Conectado com sucesso ao Supabase: {version}", ProcessType.SYSTEM)
            
            # Configura o schema se necessário
            if schema:
                cursor = self._connection.cursor()
                cursor.execute(f"CREATE SCHEMA IF NOT EXISTS {schema}")
                self._connection.commit()
                cursor.close()
                logger.log_success("connect", f"Schema '{schema}' verificado/criado", ProcessType.SYSTEM)
            
            # Cria a tabela de logs se o logger precisar
            if hasattr(logger, 'connect_to_db'):
                logger.connect_to_db(self._connection)
            
            return True
        except Exception as e:
            error_msg = str(e)
            logger.log_error("db_connect", f"Falha ao conectar ao banco de dados: {error_msg}", ProcessType.SYSTEM)
            return False
    
    def get_connection(self) -> Optional[Any]:
        """Retorna a conexão ativa ou tenta reconectar."""
        if not self._connection:
            self.connect()
        return self._connection
    
    def execute_query(self, query: str, params: Optional[Tuple] = None, commit: bool = False) -> Tuple[bool, Any]:
        """
        Executa uma query no banco de dados.
        
        Args:
            query (str): Query SQL a ser executada
            params (tuple, optional): Parâmetros para a query
            commit (bool, optional): Se deve fazer commit após a execução
            
        Returns:
            tuple: (success, result/error_message)
        """
        logger = self.initialize_logging()
        
        if not self._connection and not self.connect():
            return False, "Não foi possível conectar ao banco de dados"
        
        try:
            cursor = self._connection.cursor()
            cursor.execute(query, params)
            
            # Verifica se a query tem RETURNING clause
            has_returning = 'RETURNING' in query.upper()
            
            if commit:
                if has_returning:
                    # Para queries com RETURNING, busca o resultado antes do commit
                    result = cursor.fetchall()
                    self._connection.commit()
                else:
                    # Para outras queries, retorna o número de linhas afetadas
                    self._connection.commit()
                    result = cursor.rowcount
            else:
                result = cursor.fetchall()
                
            cursor.close()
            return True, result
        except Exception as e:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em database_service.py"
            error_msg = str(e)
            logger.log_error("execute_query", f"Erro ao executar query: {error_msg}{tb_info}", ProcessType.SYSTEM)
            return False, error_msg
    
    def close(self) -> bool:
        """Fecha a conexão com o banco de dados."""
        logger = self.initialize_logging()
        
        if self._connection:
            try:
                self._connection.close()
                self._connection = None
                return True
            except Exception as e:
                logger.log_error("db_close", f"Erro ao fechar conexão: {str(e)}", ProcessType.SYSTEM)
                return False
        return True

# Função para obter a instância singleton do gerenciador de banco de dados
def get_db_manager() -> DBManager:
    """Retorna a instância do gerenciador de banco de dados."""
    return DBManager()