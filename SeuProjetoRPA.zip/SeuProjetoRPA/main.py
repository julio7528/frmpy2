import sys,os
import traceback
from pathlib import Path
from datetime import datetime

os.system('cls')
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))
sys.path.append(str(Path(__file__).parent / "shared"))

from shared.config import settings
from shared.config.settings import initialize_logging, get_logger, get_project_info
from shared.services.logging_service import ProcessType, LogStatus
from shared.services.database_service import get_db_manager
from shared.services.email_service import send_process_start_email, send_process_end_email, send_process_error_email
from shared.services.execution_service import get_execution_service

settings.initialize_global_paths()
settings.create_directories_if_needed()
success, error_msg, project_info = settings.initialize_application()
logger = get_logger()
project_name = project_info.get('name')
project_version = project_info.get('version')
db_manager = get_db_manager()
db_manager.connect()
execution_service = get_execution_service()
execution_service.create_execution_tables()

def main():
    start_time = datetime.now()
    execution_id = None
    
    try:
        # INIT
        if not (execution_id := execution_service.start_execution()): raise Exception("Falha ao iniciar execução")
        send_process_start_email(start_time)
        
        #GET TRANSACTION DATA
        
        #PROCESS DATA
        
            #TRANSACTION 1
        if (execution_service.start_transaction("Processamento Principal")):
            try:
                logger.log_success("example_task", "Tarefa de exemplo concluída com sucesso", ProcessType.ROBOTIC)
                execution_service.end_transaction("COMPLETED")
            except Exception as e:
                tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
                logger.log_error("transaction_error", f"Erro na transação: {str(e)}{tb_info}", ProcessType.ROBOTIC)
                execution_service.end_transaction("ERROR")
        else:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
            logger.log_error("transaction_error", f"Erro na transação: {str(e)}{tb_info}", ProcessType.ROBOTIC)
            execution_service.end_transaction("ERROR")
            
            #TRANSACTION 2
        if (execution_service.start_transaction("Processamento Principal")):
            try:
                logger.log_success("example_task", "Tarefa de exemplo 2 concluída com sucesso", ProcessType.ROBOTIC)
                raise Exception("Erro na transação 2")
            except Exception as e:
                tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
                logger.log_error("transaction_error", f"Erro na transação: {str(e)}{tb_info}", ProcessType.ROBOTIC)
                execution_service.end_transaction("ERROR")
        else:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
            logger.log_error("transaction_error", f"Erro na transação: {str(e)}{tb_info}", ProcessType.ROBOTIC)
            execution_service.end_transaction("ERROR")
        
        #ENDING
        execution_service.end_execution("COMPLETED")
        send_process_end_email(start_time)
        logger.log_info("main_end", f":::Processo Finalizado:::", ProcessType.SYSTEM)
        db_manager.close()
        return 0
        
    except Exception as e:
        tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em {os.path.basename(__file__)}"
        logger.log_error("transaction_error", f"Erro na transação: {str(e)}{tb_info}", ProcessType.ROBOTIC)
        if execution_id: execution_service.end_execution("ERROR")
        send_process_error_email(start_time, error_msg, "main()")
        return 1

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
