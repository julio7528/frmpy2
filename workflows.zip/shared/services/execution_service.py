import traceback
from typing import Optional, Tuple
from datetime import datetime
from ..config.settings import get_project_info, get_logger
from .database_service import get_db_manager
from .logging_service import ProcessType

class ExecutionService:
    """Serviço para gerenciar execuções e transações do processo RPA."""
    
    def __init__(self):
        self.db_manager = get_db_manager()
        self.logger = get_logger()
        self.project_info = get_project_info()
        self.current_execution_id: Optional[int] = None
        self.current_transaction_id: Optional[int] = None
        
    def create_execution_tables(self) -> bool:
        """Cria as tabelas de execução e transação se não existirem."""
        try:
            schema = self.project_info.get('name', 'SeuProjetoRPA')
            
            # Tabela de execuções
            execution_table_sql = f"""
            CREATE TABLE IF NOT EXISTS {schema}.executions (
                id SERIAL PRIMARY KEY,
                project_name VARCHAR(255) NOT NULL,
                start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                end_time TIMESTAMP NULL,
                status VARCHAR(50) DEFAULT 'RUNNING',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
            
            # Tabela de transações
            transaction_table_sql = f"""
            CREATE TABLE IF NOT EXISTS {schema}.transactions (
                id SERIAL PRIMARY KEY,
                execution_id INTEGER REFERENCES {schema}.executions(id),
                transaction_name VARCHAR(255) NOT NULL,
                start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                end_time TIMESTAMP NULL,
                status VARCHAR(50) DEFAULT 'RUNNING',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
            
            # Executar criação das tabelas
            success1, _ = self.db_manager.execute_query(execution_table_sql, commit=True)
            success2, _ = self.db_manager.execute_query(transaction_table_sql, commit=True)
            
            if success1 and success2:
                self.logger.log_success("create_tables", "Tabelas de execução e transação criadas com sucesso", ProcessType.SYSTEM)
                return True
            else:
                tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
                self.logger.log_error("create_tables", f"Falha ao criar tabelas de execução/transação{tb_info}", ProcessType.SYSTEM)
                return False
                
        except Exception as e:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
            self.logger.log_error("create_tables", f"Erro ao criar tabelas: {str(e)}{tb_info}", ProcessType.SYSTEM)
            return False
    
    def start_execution(self) -> Optional[int]:
        """Inicia uma nova execução e retorna o ID."""
        try:
            schema = self.project_info.get('name', 'SeuProjetoRPA')
            project_name = self.project_info.get('name', 'SeuProjetoRPA')
            
            # Primeiro, inserir sem RETURNING para fazer commit
            insert_sql = f"""
            INSERT INTO {schema}.executions (project_name, status)
            VALUES (%s, %s)
            """
            
            success, _ = self.db_manager.execute_query(insert_sql, (project_name, 'RUNNING'), commit=True)
            
            if success:
                # Depois, buscar o último ID inserido
                get_id_sql = f"SELECT LASTVAL()"
                success_id, result = self.db_manager.execute_query(get_id_sql)
                
                if success_id and result:
                    self.current_execution_id = result[0][0]
                    self.logger.log_success("start_execution", f"Execução iniciada com ID: {self.current_execution_id}", ProcessType.SYSTEM)
                    return self.current_execution_id
                else:
                    tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
                    self.logger.log_error("start_execution", f"Falha ao obter ID da execução{tb_info}", ProcessType.SYSTEM)
                    return None
            else:
                tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
                self.logger.log_error("start_execution", f"Falha ao inserir execução{tb_info}", ProcessType.SYSTEM)
                return None
                
        except Exception as e:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
            self.logger.log_error("start_execution", f"Erro ao iniciar execução: {str(e)}{tb_info}", ProcessType.SYSTEM)
            return None
    
    def start_transaction(self, transaction_name: str) -> Optional[int]:
        """Inicia uma nova transação e retorna o ID."""
        if not self.current_execution_id:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
            self.logger.log_error("start_transaction", f"Nenhuma execução ativa para iniciar transação{tb_info}", ProcessType.SYSTEM)
            return None
            
        try:
            schema = self.project_info.get('name', 'SeuProjetoRPA')
            
            # Inserir transação sem RETURNING
            insert_sql = f"""
            INSERT INTO {schema}.transactions (execution_id, transaction_name, status)
            VALUES (%s, %s, %s)
            """
            
            success, _ = self.db_manager.execute_query(insert_sql, (self.current_execution_id, transaction_name, 'RUNNING'), commit=True)
            
            if success:
                # Buscar o último ID inserido
                get_id_sql = f"SELECT LASTVAL()"
                success_id, result = self.db_manager.execute_query(get_id_sql)
                
                if success_id and result:
                    self.current_transaction_id = result[0][0]
                    self.logger.log_success("start_transaction", f"Transação '{transaction_name}' iniciada com ID: {self.current_transaction_id}", ProcessType.SYSTEM)
                    return self.current_transaction_id
                else:
                    tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
                    self.logger.log_error("start_transaction", f"Falha ao obter ID da transação{tb_info}", ProcessType.SYSTEM)
                    return None
            else:
                tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
                self.logger.log_error("start_transaction", f"Falha ao inserir transação{tb_info}", ProcessType.SYSTEM)
                return None
                
        except Exception as e:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
            self.logger.log_error("start_transaction", f"Erro ao iniciar transação: {str(e)}{tb_info}", ProcessType.SYSTEM)
            return None
    
    def end_execution(self, status: str = 'COMPLETED') -> bool:
        """Finaliza a execução atual."""
        if not self.current_execution_id:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
            self.logger.log_error("end_execution", f"Nenhuma execução ativa para finalizar{tb_info}", ProcessType.SYSTEM)
            return False
            
        try:
            schema = self.project_info.get('name', 'SeuProjetoRPA')
            
            update_sql = f"""
            UPDATE {schema}.executions 
            SET end_time = CURRENT_TIMESTAMP, status = %s 
            WHERE id = %s
            """
            
            success, _ = self.db_manager.execute_query(update_sql, (status, self.current_execution_id), commit=True)
            
            if success:
                self.logger.log_success("end_execution", f"Execução {self.current_execution_id} finalizada com status: {status}", ProcessType.SYSTEM)
                self.current_execution_id = None
                return True
            else:
                tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
                self.logger.log_error("end_execution", f"Falha ao finalizar execução{tb_info}", ProcessType.SYSTEM)
                return False
                
        except Exception as e:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
            self.logger.log_error("end_execution", f"Erro ao finalizar execução: {str(e)}{tb_info}", ProcessType.SYSTEM)
            return False
    
    def end_transaction(self, status: str = 'COMPLETED') -> bool:
        """Finaliza a transação atual."""
        if not self.current_transaction_id:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
            self.logger.log_error("end_transaction", f"Nenhuma transação ativa para finalizar{tb_info}", ProcessType.SYSTEM)
            return False
            
        try:
            schema = self.project_info.get('name', 'SeuProjetoRPA')
            
            update_sql = f"""
            UPDATE {schema}.transactions 
            SET end_time = CURRENT_TIMESTAMP, status = %s 
            WHERE id = %s
            """
            
            success, _ = self.db_manager.execute_query(update_sql, (status, self.current_transaction_id), commit=True)
            
            if success:
                self.logger.log_success("end_transaction", f"Transação {self.current_transaction_id} finalizada com status: {status}", ProcessType.SYSTEM)
                self.current_transaction_id = None
                return True
            else:
                tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
                self.logger.log_error("end_transaction", f"Falha ao finalizar transação{tb_info}", ProcessType.SYSTEM)
                return False
                
        except Exception as e:
            tb_info = f" - LN {traceback.extract_stack()[-1].lineno} em execution_service.py"
            self.logger.log_error("end_transaction", f"Erro ao finalizar transação: {str(e)}{tb_info}", ProcessType.SYSTEM)
            return False
    
    def get_task_identifier(self) -> str:
        """Retorna o identificador da task atual no formato ex{id} ou ex{id}-tr{id}."""
        if self.current_transaction_id and self.current_execution_id:
            return f"ex{self.current_execution_id}-tr{self.current_transaction_id}"
        elif self.current_execution_id:
            return f"ex{self.current_execution_id}"
        else:
            return "ex0"  # Fallback caso não haja execução ativa

# Instância global do serviço de execução
_execution_service = None

def get_execution_service() -> ExecutionService:
    """Retorna a instância global do serviço de execução."""
    global _execution_service
    if _execution_service is None:
        _execution_service = ExecutionService()
    return _execution_service