import requests
from bs4 import BeautifulSoup
import csv

# URL do site com os resultados
url = "https://fabtcg.com/en/coverage/us-national-championship-2025/results/1/"

# Faz a requisição para a página
try:
    response = requests.get(url)
    response.raise_for_status()  # Lança um erro para respostas com status de falha (4xx ou 5xx)
except requests.exceptions.RequestException as e:
    print(f"Erro ao acessar a URL: {e}")
    exit()

# Analisa o conteúdo HTML da página
soup = BeautifulSoup(response.content, 'html.parser')

# Encontra todas as linhas de resultados dos jogos
match_rows = soup.find_all('div', class_='tournament-coverage__row--results')

# Abre um arquivo CSV para salvar os dados
with open('resultados_fabtcg.csv', 'w', newline='', encoding='utf-8') as f:
    # Cria o escritor de CSV e define os nomes das colunas
    writer = csv.writer(f)
    writer.writerow(['player1', 'linkchecklistp1', 'player2', 'linkchecklistp2', 'winner'])

    # Itera sobre cada linha de resultado
    for match in match_rows:
        try:
            # --- Jogador 1 ---
            player1_element = match.select_one('.tournament-coverage__p1')
            player1_name = player1_element.select_one('.tournament-coverage__player-name-and-flag span').text.strip()
            
            # O link da decklist pode não existir, então usamos um try-except
            try:
                # O link está em uma tag <a> dentro da div do herói
                link_p1_tag = player1_element.select_one('.tournament-coverage__player-hero-and-deck a')
                link_p1 = link_p1_tag['href'] if link_p1_tag else 'N/A'
            except (AttributeError, TypeError):
                link_p1 = 'N/A'

            # --- Jogador 2 ---
            player2_element = match.select_one('.tournament-coverage__p2')
            player2_name = player2_element.select_one('.tournament-coverage__player-name-and-flag span').text.strip()
            
            # Tenta obter o link da decklist do jogador 2
            try:
                link_p2_tag = player2_element.select_one('.tournament-coverage__player-hero-and-deck a')
                link_p2 = link_p2_tag['href'] if link_p2_tag else 'N/A'
            except (AttributeError, TypeError):
                link_p2 = 'N/A'

            # --- Vencedor ---
            if 'tournament-coverage__row--winner-1' in match.get('class', []):
                winner = player1_name
            elif 'tournament-coverage__row--winner-2' in match.get('class', []):
                winner = player2_name
            elif 'tournament-coverage__row--draw' in match.get('class', []):
                winner = "Draw" # Empate
            else:
                winner = "Não especificado"
            
            # Escreve a linha de dados no arquivo CSV
            writer.writerow([player1_name, link_p1, player2_name, link_p2, winner])

        except AttributeError as e:
            # Pula linhas que não tenham a estrutura esperada
            print(f"Aviso: Pulando uma linha de partida devido a um formato inesperado. Erro: {e}")
            continue

print("Os dados foram extraídos e salvos com sucesso no arquivo 'resultados_fabtcg.csv'")