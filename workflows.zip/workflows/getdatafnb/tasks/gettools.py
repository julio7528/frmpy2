# gerador_deck_csv.py
import requests
from bs4 import BeautifulSoup
import csv
import os
import time
import re
import sys
from pathlib import Path
import json

# Adiciona o diretório raiz do projeto ao path
project_root = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(project_root))
sys.path.append(str(project_root / "shared"))

from shared.config.settings import get_logger
from shared.services.logging_service import ProcessType

class GetToolsTask:
    def __init__(self):
        self.logger = get_logger()
        self.config = self._load_config()
        
    def _load_config(self):
        """Carrega a configuração do arquivo config.json"""
        try:
            config_path = project_root / "shared" / "config" / "config.json"
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            self.logger.log_error("config_load_error", f"Erro ao carregar configuração: {str(e)}", ProcessType.ROBOTIC)
            raise
    
    def _scrape_deck_info(self, decklist_url, deck_writer):
        """
        Acessa a URL de uma decklist e extrai APENAS a seção 
        'Hero / Weapon / Equipment' para o arquivo deck.csv.
        """
        if not decklist_url or decklist_url == 'N/A':
            return

        base_url = self.config['fabtcg']['base_url']
        full_url = f"{base_url}{decklist_url}"
        self.logger.log_info("deck_processing", f"[Deck Extractor] Processando: {full_url}", ProcessType.ROBOTIC)

        try:
            response = requests.get(full_url)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            self.logger.log_error("deck_request_error", f"Erro ao acessar {full_url}: {str(e)}", ProcessType.ROBOTIC)
            return

        soup = BeautifulSoup(response.content, 'html.parser')

        # Extrai Nome do Jogador e ID
        player_name, player_id = "Não encontrado", "Não encontrado"
        try:
            player_info_header = soup.find('th', string=re.compile(r'Player Name / ID'))
            player_info_cell = player_info_header.find_next_sibling('td')
            info_match = re.search(r'(.+?)\s*\((\d+)\)', player_info_cell.text)
            if info_match:
                player_name, player_id = info_match.group(1).strip(), info_match.group(2).strip()
        except Exception:
            pass

        # Encontra a tabela específica de Hero / Weapon / Equipment
        hero_table_header = soup.find('th', string=re.compile(r'Hero / Weapon / Equipment'))
        if not hero_table_header:
            return
            
        table = hero_table_header.find_parent('table')
        card_rows = table.find_all('tr')[1:] # Pula a linha do cabeçalho

        for row in card_rows:
            cell = row.find('td')
            if not cell: continue

            hover_img_div = cell.find('div', class_='hover_img')
            if not hover_img_div: continue

            match = re.match(r'(\d+)\s*x\s*(.*)', hover_img_div.get_text(strip=True))
            if not match: continue

            quantity, card_name = match.group(1).strip(), match.group(2).strip()
            image_tag = hover_img_div.find('img')
            image_link = image_tag['src'] if image_tag else 'N/A'
            
            deck_writer.writerow([player_name, player_id, quantity, card_name, image_link])

        time.sleep(1)

    def execute(self):
        """Executa a extração de dados de tools/deck"""
        try:
            self.logger.log_info("tools_extraction_start", "Iniciando extração de tools/deck do FABTCG", ProcessType.ROBOTIC)
            
            # Cria o diretório de saída se não existir
            output_dir = project_root / "data" / "temp"
            output_dir.mkdir(parents=True, exist_ok=True)
            
            input_csv_file = output_dir / 'match.csv'
            if not input_csv_file.exists():
                self.logger.log_error("input_file_error", f"Erro: Arquivo '{input_csv_file}' não encontrado. Execute o script de matches primeiro.", ProcessType.ROBOTIC)
                return False

            output_file = output_dir / 'tools.csv'
            with open(output_file, 'w', newline='', encoding='utf-8') as deck_file:
                deck_writer = csv.writer(deck_file)
                deck_writer.writerow(['playername', 'playerid', 'quantitycards', 'cardname', 'imagelink'])

                with open(input_csv_file, 'r', encoding='utf-8') as results_file:
                    reader = csv.DictReader(results_file)
                    processed_decks = 0
                    for i, row in enumerate(reader):
                        if i >= 10: break # Limite de teste
                        
                        winner_name = row.get('winner')
                        winner_deck_url = row.get('linkchecklistp1') if winner_name == row.get('player1') else row.get('linkchecklistp2')
                        
                        if winner_name in [row.get('player1'), row.get('player2')]:
                            self._scrape_deck_info(winner_deck_url, deck_writer)
                            processed_decks += 1

            self.logger.log_success("tools_extraction_complete", f"Processo de extração de tools/deck concluído! {processed_decks} decks processados. Arquivo salvo: '{output_file}'", ProcessType.ROBOTIC)
            return True
            
        except Exception as e:
            self.logger.log_error("tools_extraction_error", f"Erro na extração de tools/deck: {str(e)}", ProcessType.ROBOTIC)
            return False